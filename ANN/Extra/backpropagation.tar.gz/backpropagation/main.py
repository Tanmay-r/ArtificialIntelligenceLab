import backpropagationv3
import numpy as np
import math
import buildInput
import functions

for i in range(1,5):
	if (i==1):
		inputArray = buildInput.buildInput(2)
		outputArray = functions.f_XOR(inputArray)
		layer = np.array([3, 3, 2])
		wt = backpropagationv3.initializeW(layer, 1)
		M = 0.8
		for j in range(1,11):
			w = wt
			backpropagationv3.backpropagation(layer, inputArray, outputArray, w ,j/10.0 , M)
			print "!!!"
		print "*****************"

	elif (i==2):
		inputArray = buildInput.buildInput(2)
		outputArray = functions.f_OR(inputArray)
		layer = np.array([3, 3, 2])
		wt = backpropagationv3.initializeW(layer, 1)
		M = 0.8
		for j in range(1,11):
			w = wt
			backpropagationv3.backpropagation(layer, inputArray, outputArray, w ,j/10.0 , M)
		print "*****************"

	elif (i==3):
		inputArray = buildInput.buildInput(5)
		outputArray = functions.f_Palindrome(inputArray)
		layer = np.array([6, 6, 1])
		wt = backpropagationv3.initializeW(layer, 2)
		M = 0.8
		for j in range(1,11):
			w = wt
			backpropagationv3.backpropagation(layer, inputArray, outputArray, w ,j/10.0 , M)
		print "*****************"

	elif (i==4):
		inputArray = buildInput.buildInput(5)
		outputArray = functions.f_IsMajority(inputArray)
		layer = np.array([6, 6, 1])
		wt = backpropagationv3.initializeW(layer, 1)
		M = 0.8
		for j in range(1,11):
			w = wt
			backpropagationv3.backpropagation(layer, inputArray, outputArray, w ,j/10.0 , M)